//
//  ViewController.swift
//  hw11
//
//  Created by Алексей on 4.07.24.
//

import UIKit

class ViewController: UIViewController {
    
    var mainStackView: UIStackView = {
       let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .top
        stackView.distribution = .equalCentering
        stackView.spacing = 10
        stackView.backgroundColor = .black
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    let firstLine: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.alignment = .top
        stackView.distribution = .equalSpacing
        stackView.spacing = 10
        return stackView
    }()
    
    let secondLine: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.alignment = .top
        stackView.distribution = .equalSpacing
        stackView.spacing = 10
        return stackView
    }()
    
    let thirdLine: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.alignment = .fill
        stackView.distribution = .equalSpacing
        stackView.spacing = 14
        return stackView
    }()
    
    let fourthLine: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.alignment = .top
        stackView.distribution = .equalSpacing
        stackView.spacing = 14
        return stackView
    }()
    
    let fifthLine: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.alignment = .top
        stackView.distribution = .equalSpacing
        stackView.spacing = 10
        return stackView
    }()
    
    let resultLabel: UILabel = {
       let label = UILabel()
        label.font = .systemFont(ofSize: 90)
        label.textColor = .white
        label.text = "0"
        label.textAlignment = .right
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    func makeMainStackView() {
        view.addSubview(mainStackView)
                NSLayoutConstraint.activate([
                    mainStackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                    mainStackView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
                    mainStackView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
                    mainStackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
                ])
    }
    
    func createButton(title: String, backGroundColor: UIColor, textColor: UIColor, width: CGFloat, height: CGFloat) -> UIButton {
        let button: UIButton = {
            let button = UIButton()
            button.layer.cornerRadius = 45
            button.setTitle(title, for: .normal)
            button.titleLabel?.font = .systemFont(ofSize: 40)
            button.setTitleColor(textColor, for: .normal)
            button.backgroundColor = backGroundColor
            button.widthAnchor.constraint(equalToConstant: width).isActive = true
            button.heightAnchor.constraint(equalToConstant: height).isActive = true
            button.translatesAutoresizingMaskIntoConstraints = false
            return button
        }()
        return button
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        makeMainStackView()
        mainStackView.addArrangedSubview(resultLabel)
        mainStackView.addArrangedSubview(firstLine)
        mainStackView.addArrangedSubview(secondLine)
        mainStackView.addArrangedSubview(thirdLine)
        mainStackView.addArrangedSubview(fourthLine)
        mainStackView.addArrangedSubview(fifthLine)
        //MARK: - Create buttons
        let acButton = createButton(title: "AC", backGroundColor: .calgrey, textColor: .black, width: 88, height: 88)
        let plusMinusButton = createButton(title: "+/-", backGroundColor: .calgrey, textColor: .black, width: 88, height: 88)
        let procentButton = createButton(title: "%", backGroundColor: .calgrey, textColor: .black, width: 88, height: 88)
        let devineButton = createButton(title: "÷", backGroundColor: .orangeCalc, textColor: .calwhite, width: 88, height: 88)
        let sevenButton = createButton(title: "7", backGroundColor: .calcblack, textColor: .calwhite, width: 88, height: 88)
        let eightButton = createButton(title: "8", backGroundColor: .calcblack, textColor: .calwhite, width: 88, height: 88)
        let nineButton = createButton(title: "9", backGroundColor: .calcblack, textColor: .calwhite, width: 88, height: 88)
        let multiplyButton = createButton(title: "×", backGroundColor: .orangeCalc, textColor: .calwhite, width: 88, height: 88)
        let fourButton = createButton(title: "4", backGroundColor: .calcblack, textColor: .calwhite, width: 88, height: 88)
        let fiveButton = createButton(title: "5", backGroundColor: .calcblack, textColor: .calwhite, width: 88, height: 88)
        let sixButton = createButton(title: "6", backGroundColor: .calcblack, textColor: .calwhite, width: 88, height: 88)
        let minusButton = createButton(title: "-", backGroundColor: .orangeCalc, textColor: .calwhite, width: 88, height: 88)
        let oneButton = createButton(title: "1", backGroundColor: .calcblack, textColor: .calwhite, width: 88, height: 88)
        let twoButton = createButton(title: "2", backGroundColor: .calcblack, textColor: .calwhite, width: 88, height: 88)
        let threeButton = createButton(title: "3", backGroundColor: .calcblack, textColor: .calwhite, width: 88, height: 88)
        let plusButton = createButton(title: "+", backGroundColor: .orangeCalc, textColor: .calwhite, width: 88, height: 88)
        let zeroButton = createButton(title: "0", backGroundColor: .calcblack, textColor: .calwhite, width: 88 * 2, height: 88)
        let zapButton = createButton(title: ",", backGroundColor: .calcblack, textColor: .calwhite, width: 88, height: 88)
        let equalButton = createButton(title: "=", backGroundColor: .orangeCalc, textColor: .calwhite, width: 88, height: 88)
        //MARK: - Create constraints
        NSLayoutConstraint.activate([
            resultLabel.topAnchor.constraint(equalTo: mainStackView.safeAreaLayoutGuide.topAnchor, constant: 10),
                  resultLabel.trailingAnchor.constraint(equalTo: mainStackView.trailingAnchor, constant: -40),
                  resultLabel.leadingAnchor.constraint(equalTo: mainStackView.leadingAnchor),
                  resultLabel.heightAnchor.constraint(equalToConstant: 120),
            firstLine.topAnchor.constraint(equalTo: resultLabel.bottomAnchor, constant: 14)
              ])
        //MARK: - Create calculator
        firstLine.addArrangedSubview(acButton)
        firstLine.addArrangedSubview(plusMinusButton)
        firstLine.addArrangedSubview(procentButton)
        firstLine.addArrangedSubview(devineButton)
        secondLine.addArrangedSubview(sevenButton)
        secondLine.addArrangedSubview(eightButton)
        secondLine.addArrangedSubview(nineButton)
        secondLine.addArrangedSubview(multiplyButton)
        thirdLine.addArrangedSubview(fourButton)
        thirdLine.addArrangedSubview(fiveButton)
        thirdLine.addArrangedSubview(sixButton)
        thirdLine.addArrangedSubview(minusButton)
        fourthLine.addArrangedSubview(oneButton)
        fourthLine.addArrangedSubview(twoButton)
        fourthLine.addArrangedSubview(threeButton)
        fourthLine.addArrangedSubview(plusButton)
        fifthLine.addArrangedSubview(zeroButton)
        fifthLine.addArrangedSubview(zapButton)
        fifthLine.addArrangedSubview(equalButton)
    }
}


